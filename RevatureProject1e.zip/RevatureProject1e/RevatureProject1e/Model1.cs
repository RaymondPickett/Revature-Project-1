namespace RevatureProject1e
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<Account> Accounts { get; set; }
        public virtual DbSet<Transaction> Transactions { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>()
                .Property(e => e.name)
                .IsUnicode(false);

            modelBuilder.Entity<Account>()
                .Property(e => e.type)
                .IsUnicode(false);

            modelBuilder.Entity<Account>()
                .HasMany(e => e.Transactions)
                .WithOptional(e => e.Account)
                .HasForeignKey(e => e.associatedAccountId);

            modelBuilder.Entity<Transaction>()
                .Property(e => e.details)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.userName)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .Property(e => e.password)
                .IsUnicode(false);

            modelBuilder.Entity<User>()
                .HasMany(e => e.Accounts)
                .WithOptional(e => e.User)
                .HasForeignKey(e => e.ownerId);
        }
    }
}
