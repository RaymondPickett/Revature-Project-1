﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RevatureProject1e;

namespace RevatureProject1e.Controllers
{
    public class TransactionsController : Controller
    {
        private Model1 db = new Model1();

        // GET: Transactions
        public ActionResult Index()
        {
            var transactions = db.Transactions.Include(t => t.Account);
            return View(transactions.ToList());
        }

        public ActionResult AccountTransactions(int? id)
        {
            int index = 0;
            var transactions = db.Transactions.Include(t => t.Account);
            List<Transaction> transactionsList = transactions.ToList();

            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (transaction.associatedAccountId != id)
                {
                    transactionsList.RemoveAt(index);
                    index--;
                }
                index++;
            }
            if (transactionsList.Count == 0)
            {
                Transaction dummyTransaction = new Transaction();
                dummyTransaction.associatedAccountId = id;
                transactionsList.Add(dummyTransaction);
            }
            return View(transactionsList);
        }

        public ActionResult Account10Transactions(int? id)
        {
            int index = 0;
            var transactions = db.Transactions.Include(t => t.Account);
            List<Transaction> transactionsList = transactions.ToList();

            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (transaction.associatedAccountId != id)
                {
                    transactionsList.RemoveAt(index);
                    index--;
                }
                index++;
            }
            if (transactionsList.Count == 0)
            {
                Transaction dummyTransaction = new Transaction();
                dummyTransaction.associatedAccountId = id;
                transactionsList.Add(dummyTransaction);
            }
            else if (transactionsList.Count > 10)
            {
                List<Transaction> transactionsList2 = new List<Transaction>();
                int counter = 1;

                while (counter <= 10)
                {
                    transactionsList2.Add(transactionsList[transactionsList.Count - counter]);
                    counter++;
                }
                return View(transactionsList2);
            }
            return View(transactionsList);
        }

        public ActionResult AccountDatesTransactions(int? id, DateTime dateOne, DateTime dateTwo)
        {
            int index = 0;
            var transactions = db.Transactions.Include(t => t.Account);
            List<Transaction> transactionsList = transactions.ToList();

            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (transaction.associatedAccountId != id)
                {
                    transactionsList.RemoveAt(index);
                    index--;
                }
                index++;
            }

            index = 0;
            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (dateOne.CompareTo(transaction.date) > 0)
                {
                    transactionsList.RemoveAt(index);
                    index--;
                }
                index++;
            }

            index = 0;
            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (dateTwo.CompareTo(transaction.date) < 0)
                {
                    transactionsList.RemoveAt(index);
                    index--;
                }
                index++;
            }

            if (transactionsList.Count == 0)
            {
                Transaction dummyTransaction = new Transaction();
                dummyTransaction.associatedAccountId = id;
                transactionsList.Add(dummyTransaction);
            }
            return View(transactionsList);
        }

        // GET: Transactions/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Transaction transaction = db.Transactions.Find(id);
            if (transaction == null)
            {
                return HttpNotFound();
            }
            return View(transaction);
        }

        // GET: Transactions/Create
        public ActionResult Create()
        {
            ViewBag.associatedAccountId = new SelectList(db.Accounts, "accountId", "name");
            return View();
        }

        // POST: Transactions/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "transactionId,details,date,associatedAccountId")] Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                db.Transactions.Add(transaction);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.associatedAccountId = new SelectList(db.Accounts, "accountId", "name", transaction.associatedAccountId);
            return View(transaction);
        }

        // GET: Transactions/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Transaction transaction = db.Transactions.Find(id);
            if (transaction == null)
            {
                return HttpNotFound();
            }
            ViewBag.associatedAccountId = new SelectList(db.Accounts, "accountId", "name", transaction.associatedAccountId);
            return View(transaction);
        }

        // POST: Transactions/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "transactionId,details,date,associatedAccountId")] Transaction transaction)
        {
            if (ModelState.IsValid)
            {
                db.Entry(transaction).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.associatedAccountId = new SelectList(db.Accounts, "accountId", "name", transaction.associatedAccountId);
            return View(transaction);
        }

        // GET: Transactions/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Transaction transaction = db.Transactions.Find(id);
            if (transaction == null)
            {
                return HttpNotFound();
            }
            return View(transaction);
        }

        // POST: Transactions/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Transaction transaction = db.Transactions.Find(id);
            db.Transactions.Remove(transaction);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
