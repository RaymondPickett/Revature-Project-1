﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RevatureProject1e;

namespace RevatureProject1e.Controllers
{
    public class AccountsController : Controller
    {
        private Model1 db = new Model1();

        // GET: Accounts
        public ActionResult Index()
        {
            var accounts = db.Accounts.Include(a => a.User);
            return View(accounts.ToList());
        }

        public ActionResult userAccounts(int? id)
        {
            int index = 0;
            var accounts = db.Accounts.Include(a => a.User);
            List<Account> accountsList = accounts.ToList();

            foreach (Account account in accountsList.ToList())
            {
                if (account.ownerId != id)
                {
                    accountsList.RemoveAt(index);
                    index--;
                }
                index++;
            }
            if (accountsList.Count == 0)
            {
                Account dummyAccount = new Account();
                dummyAccount.ownerId = id;
                dummyAccount.typeId = -1;
                accountsList.Add(dummyAccount);
            }
            return View(accountsList);
        }

        // GET: Accounts/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            return View(account);
        }

        //Withdraw
        public ActionResult Withdraw(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            return View(account);
        }

        //Deposit
        public ActionResult Deposit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            return View(account);
        }

        //Complete Deposit
        public ActionResult CompleteDeposit(int? id, float? ammount)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            account.money = account.money + ammount;
            Transaction addMe = new Transaction();
            addMe.associatedAccountId = id;
            addMe.details = "Deposited $" + ammount + " into this account.";
            addMe.date = DateTime.Now;
            db.Transactions.Add(addMe);
            db.SaveChanges();
            return View(account);
        }

        //Complete Withdraw
        public ActionResult CompleteWithdraw(int? id, float? ammount)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            account.money = account.money - ammount;
            Transaction addMe = new Transaction();
            addMe.details = "Withdrew $" + ammount + " from this account.";
            addMe.associatedAccountId = id;
            addMe.date = DateTime.Now;
            db.Transactions.Add(addMe);
            db.SaveChanges();
            return View(account);
        }

        //Transfer
        public ActionResult Transfer(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            return View(account);
        }

        // GET: Accounts/Create
        public ActionResult Create()
        {
            ViewBag.ownerId = new SelectList(db.Users, "userId", "userName");
            return View();
        }

        //Complete Transfer
        public ActionResult CompleteTransfer(int? id, float? ammount, int? id2)
        {

            Account account = db.Accounts.Find(id);
            Account account2 = db.Accounts.Find(id2);
            if (account2 != null && account2.type != "TERM DEPOSIT" && (account.ownerId == account2.ownerId))
            {
                if (account2.type != "LOAN" || (ammount + account2.money) <= 0)
                { 
                    account2.money = account2.money + ammount;
                    account.money = account.money - ammount;

                    Transaction addMe = new Transaction();
                    addMe.details = "Transfered $" + ammount + " from this account to " + account2.name;
                    addMe.associatedAccountId = id;
                    addMe.date = DateTime.Now;
                    db.Transactions.Add(addMe);
                    Transaction addMe2 = new Transaction();
                    addMe2.details = "Recieved $" + ammount + " from " + account.name;
                    addMe2.associatedAccountId = id2;
                    addMe2.date = DateTime.Now;
                    db.Transactions.Add(addMe2);
                    db.SaveChanges();
                }
            }
            return View(account);
        }

        // POST: Accounts/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "accountId,name,money,typeId,type,maturityDate,ownerId")] Account account)
        {
            if (ModelState.IsValid)
            {
                db.Accounts.Add(account);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ownerId = new SelectList(db.Users, "userId", "userName", account.ownerId);
            return View(account);
        }

        public ActionResult CreateForUser(int? id)
        {
            User user = db.Users.Find(id);
            return View(user);
        }

        public ActionResult CompleteCreateForUser(int? id, string name, float? money, string type, DateTime maturityDate)
        {

            Account account = new Account();

            account.ownerId = id;
            account.name = name;
            account.money = money;
            account.type = type;
            if (account.type == "TERM DEPOSIT")
            {
                account.maturityDate = maturityDate;
            }

            db.Accounts.Add(account);
            db.SaveChanges();
            return View(account);
        }

        public ActionResult CompleteCreateForUser2(int? id, string name, float? money, string type)
        {

            Account account = new Account();

            account.ownerId = id;
            account.name = name;
            account.money = money;
            account.type = type;
            if (account.type == "TERM DEPOSIT")
            {
                account.maturityDate = new DateTime(2021, 1, 1);
            }

            db.Accounts.Add(account);
            db.SaveChanges();
            return View(account);
        }

        // GET: Accounts/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }
            ViewBag.ownerId = new SelectList(db.Users, "userId", "userName", account.ownerId);
            return View(account);
        }

        // POST: Accounts/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "accountId,name,money,typeId,type,maturityDate,ownerId")] Account account)
        {
            if (ModelState.IsValid)
            {
                db.Entry(account).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ownerId = new SelectList(db.Users, "userId", "userName", account.ownerId);
            return View(account);
        }

        // GET: Accounts/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Account account = db.Accounts.Find(id);
            if (account == null)
            {
                return HttpNotFound();
            }

            return View(account);
        }

        // POST: Accounts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            int index = 0;
            var transactions = db.Transactions.Include(t => t.Account);
            List<Transaction> transactionsList = transactions.ToList();

            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (transaction.associatedAccountId == id)
                {
                    db.Transactions.Remove(transaction);
                }
                index++;
            }

            Account account = db.Accounts.Find(id);
            db.Accounts.Remove(account);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult CompleteDelete(int id)
        {
            int index = 0;
            var transactions = db.Transactions.Include(t => t.Account);
            List<Transaction> transactionsList = transactions.ToList();

            foreach (Transaction transaction in transactionsList.ToList())
            {
                if (transaction.associatedAccountId == id)
                {
                    db.Transactions.Remove(transaction);
                }
                index++;
            }

            Account account = db.Accounts.Find(id);
            Account returnMe = new Account();
            returnMe.ownerId = account.ownerId;
            db.Accounts.Remove(account);
            db.SaveChanges();
            return View(returnMe);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
