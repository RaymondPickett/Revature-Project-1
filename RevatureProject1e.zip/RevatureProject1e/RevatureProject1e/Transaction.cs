namespace RevatureProject1e
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Transaction
    {
        public int transactionId { get; set; }

        public string details { get; set; }

        public DateTime? date { get; set; }

        public int? associatedAccountId { get; set; }

        public virtual Account Account { get; set; }
    }
}
